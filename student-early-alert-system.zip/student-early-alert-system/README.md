# 🎓 Student Early Alert & Retention System (SEAS)
> **Full Stack Development II (FSD 2) Capstone Project**  
> Built with **Node.js, Express.js, MongoDB (Mongoose), and Modern Responsive Web Dashboard** in **Visual Studio Code**.

---

## 📌 1. Project Overview & Architecture

The **Student Early Alert System (SEAS)** is an automated full-stack academic monitoring, early-warning, and student retention platform. It implements role-based access control (RBAC) with strict separation of duties between **Administrators** and **Teachers / Mentors**.

---

## 🛡️ 2. ADMIN CAPABILITIES

The institutional administrator possesses system-wide oversight and governance privileges:

- **Authentication & Dashboard**: Secure JWT login with institution-wide executive KPIs (Total enrolled students, active accounts, critical alert volume, audit record counter).
- **Student Management**: Create, edit, activate/deactivate, and view all student profiles across departments.
- **Teacher & Mentor Management**: Create teacher accounts, assign departments, and toggle active/inactive account status with recorded audit justification.
- **Academic Structure Management**:
  - **Departments**: Create and manage academic departments (CSE, IT, ECE, etc.).
  - **Classes & Sections**: Create and manage classes (e.g., CSE-4A, IT-4B).
  - **Subjects & Mapping**: Create subjects and map subjects to faculty instructors.
- **Student-Mentor Allocation**: Assign students (individually or in cohorts) to specific faculty mentors.
- **Configurable Warning Thresholds**: Dynamically configure campus-wide trigger parameters:
  - Attendance Warning % (Default: 75%)
  - Attendance Critical % (Default: 65%)
  - Marks Warning Benchmark (Default: 55%)
  - Marks Critical Benchmark (Default: 40%)
  - Consecutive Absence Limit (Default: 3 days)
  - Missing Assignment Overdue Limit (Default: 2)
- **Institution-Wide Analytics**: Real-time campus risk distribution charts, department risk comparisons, and teacher caseload monitors.
- **System-Wide Alerts**: Inspect all triggered alerts across all departments and academic levels.
- **CRITICAL COMPLIANCE RULE — Mandatory Audit Trail**:
  > **"Admin must NOT modify a student's academic records without an appropriate audit trail."**  
  Any administrative override of attendance or marks strictly requires a documented justification. If the justification is omitted, the API rejects the request (`HTTP 400`). All overrides generate an immutable entry in the `AuditLog` collection.

---

## 👨‍🏫 3. TEACHER / MENTOR CAPABILITIES

The teacher/mentor is responsible for direct academic monitoring, guidance, and retention of their assigned cohort:

- **Teacher Workstation & Dashboard**: View assigned mentees count, critical mentees, active mentee alerts, pending follow-ups, and assigned subjects.
- **Assigned Students Roster**: Search and filter assigned mentees by Roll Number, Name, Risk Level, and Class.
- **Performance Trend Tracking**: Identifies student trajectory as **↗ Improving (Green)**, **→ Stable (Grey)**, or **↘ Declining (Red)**.
- **Enter / Update Marks & Attendance**:
  - Attended classes vs. total classes.
  - Consecutive unexcused absences counter.
  - Continuous internal examination scores (out of 50).
  - Continuous evaluation assignments submitted vs. total given.
  - Teacher remarks and academic notes.
- **Early-Warning Alerts with Root Causes**: Direct feed of triggered alerts for assigned mentees with detailed root-cause explanation (e.g., attendance deficit, assessment failure, chronic absences).
- **Guidance & Intervention Studio**:
  - Log 1-on-1 counseling, remedial classes, or parent conferences.
  - Record student commitments and discussion notes.
  - **Schedule Follow-Up Sessions** with specific target dates.
  - **Mark Completed & Measure Improvement**: Compares pre-intervention risk against post-intervention risk to record measurable retention outcomes (**IMPROVED**, **STABLE**, **DECLINING**).
  - View full chronological intervention history.

---

## 🧮 4. The Early Warning Risk Algorithm (`backend/utils/riskEngine.js`)

$$\text{Composite Risk Index} = (0.40 \times P_{\text{attendance}}) + (0.35 \times P_{\text{academics}}) + (0.15 \times P_{\text{assignments}}) + (0.10 \times P_{\text{absences}})$$

- **$P_{\text{attendance}}$ (40% Weight)**: Heavy penalty when attendance falls below institutional threshold.
- **$P_{\text{academics}}$ (35% Weight)**: Evaluates continuous internal assessment marks.
- **$P_{\text{assignments}}$ (15% Weight)**: Evaluates continuous assessment backlog.
- **$P_{\text{absences}}$ (10% Weight)**: Flags consecutive unexcused absent days.

#### Risk Categorization:
- 🔴 **CRITICAL RISK (Red)**: Score $\ge 60$, or Attendance $< 65\%$, or Internals $< 40\%$.
- 🟡 **MODERATE RISK (Yellow)**: Score $35 - 59$, or Attendance $< 75\%$.
- 🟢 **SAFE STANDING (Green)**: Score $< 35$.

---

## 🚀 5. How to Run in VS Code (Two Terminals)

### Terminal 1: Backend API (Port 5000)
```powershell
cd C:\Users\DELL\.gemini\antigravity\scratch\student-early-alert-system
npm run server
```

### Terminal 2: Frontend Client (Port 3000)
```powershell
cd C:\Users\DELL\.gemini\antigravity\scratch\student-early-alert-system\frontend
npm run dev
```

Open your browser at:
👉 **`http://localhost:3000`**

---

## 🔑 6. Pre-configured Demo Logins

Use the top navigation bar's **Quick Switcher** or log in with:

| Role | Email | Password | Primary Capabilities |
| :--- | :--- | :--- | :--- |
| **🛡️ Administrator** | `admin@college.edu` | `Password@123` | Institutional analytics, teacher management, threshold configuration, audit trail |
| **👨‍🏫 Teacher / Mentor** | `faculty@college.edu` | `Password@123` | Monitor assigned mentees, enter marks/attendance, guidance studio, follow-ups |
| **👩‍💼 Advisor** | `advisor@college.edu` | `Password@123` | Student counseling, remedial classes, alert assignments |
| **🎓 Student** | `rahul.sharma@student.edu` | `Password@123` | Self-service risk gauge, attendance eligibility, recovery tips |

---

## 🧪 7. REST Client API Testing

Open [`api.http`](file:///C:/Users/DELL/.gemini/antigravity/scratch/student-early-alert-system/api.http) in VS Code with the **REST Client** extension to test all Admin, Teacher, and Student endpoints directly.
