const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/student_early_alert');
    console.log(`[MongoDB Connected]: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`[MongoDB Connection Error]: ${error.message}`);
    console.warn(`Tip: If running locally on Windows, make sure MongoDB is running, or set MONGODB_URI in .env to your MongoDB Atlas connection string.`);
    // Do not crash immediately so helpful HTTP errors can be sent if needed
  }
};

module.exports = connectDB;
