const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Student = require('../models/Student');
const Attendance = require('../models/Attendance');
const AcademicRecord = require('../models/AcademicRecord');
const { calculateRiskScore, getActiveThresholds } = require('../utils/riskEngine');

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'early_alert_jwt_secret_key_fsd2_2026', {
    expiresIn: '7d'
  });
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
  try {
    const { name, email, password, role, department } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ success: false, message: 'User already exists with this email' });
    }

    let studentRef = null;

    // If registering as a student, automatically link or create their Student academic profile
    if (role === 'student') {
      let student = await Student.findOne({ email });
      if (!student) {
        student = await Student.findOne({ name: new RegExp('^' + name.trim() + '$', 'i') });
      }

      if (!student) {
        const count = await Student.countDocuments();
        const rollNo = `21CS${String(count + 1).padStart(3, '0')}`;
        const thresholds = await getActiveThresholds();
        const { riskScore, riskStatus } = calculateRiskScore({
          attendancePercentage: 88.0,
          averageInternalPercentage: 80.0,
          missingAssignments: 0,
          consecutiveAbsences: 0
        }, thresholds);

        student = await Student.create({
          rollNo,
          name: name.trim(),
          email: email.trim(),
          department: department || 'Computer Science',
          semester: 4,
          section: 'A',
          attendancePercentage: 88.0,
          averageInternalPercentage: 80.0,
          riskScore,
          riskStatus,
          status: 'active'
        });

        // Initialize default courses for the new student
        const defaultCourses = [
          { code: 'CS401', name: 'Full Stack Development 2' },
          { code: 'CS402', name: 'Database Management Systems' },
          { code: 'CS403', name: 'Design and Analysis of Algorithms' },
          { code: 'CS404', name: 'Computer Networks' }
        ];

        for (const c of defaultCourses) {
          await Attendance.create({
            student: student._id,
            courseCode: c.code,
            courseName: c.name,
            totalClasses: 30,
            attendedClasses: 27
          });

          await AcademicRecord.create({
            student: student._id,
            courseCode: c.code,
            courseName: c.name,
            internalMarks: 40,
            maxInternalMarks: 50,
            submittedAssignments: 5,
            totalAssignments: 5
          });
        }
      }

      studentRef = student._id;
    }

    const user = await User.create({
      name,
      email,
      password,
      role: role || 'faculty',
      department: department || 'Computer Science',
      studentRef
    });

    const populatedUser = await User.findById(user._id).populate('studentRef');

    res.status(201).json({
      success: true,
      data: {
        _id: populatedUser._id,
        name: populatedUser.name,
        email: populatedUser.email,
        role: populatedUser.role,
        department: populatedUser.department,
        studentRef: populatedUser.studentRef,
        token: generateToken(populatedUser._id)
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Auth user & get token
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    let user = await User.findOne({ email }).populate('studentRef').populate('assignedSubjects');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    if (user.status === 'inactive') {
      return res.status(403).json({
        success: false,
        message: 'Account is deactivated. Please contact the institutional administrator.'
      });
    }

    if (await user.matchPassword(password)) {
      // If student user is not linked to a Student profile yet, automatically link or create it
      if (user.role === 'student' && !user.studentRef) {
        let student = await Student.findOne({ email: user.email });
        if (!student) {
          student = await Student.findOne({ name: new RegExp('^' + user.name.trim() + '$', 'i') });
        }

        if (!student) {
          const count = await Student.countDocuments();
          const rollNo = `21CS${String(count + 1).padStart(3, '0')}`;
          student = await Student.create({
            rollNo,
            name: user.name,
            email: user.email,
            department: user.department || 'Computer Science',
            semester: 4,
            section: 'A',
            attendancePercentage: 88.0,
            averageInternalPercentage: 80.0,
            riskScore: 10,
            riskStatus: 'SAFE',
            status: 'active'
          });

          const defaultCourses = [
            { code: 'CS401', name: 'Full Stack Development 2' },
            { code: 'CS402', name: 'Database Management Systems' },
            { code: 'CS403', name: 'Design and Analysis of Algorithms' },
            { code: 'CS404', name: 'Computer Networks' }
          ];

          for (const c of defaultCourses) {
            await Attendance.create({
              student: student._id,
              courseCode: c.code,
              courseName: c.name,
              totalClasses: 30,
              attendedClasses: 27
            });
            await AcademicRecord.create({
              student: student._id,
              courseCode: c.code,
              courseName: c.name,
              internalMarks: 40,
              maxInternalMarks: 50,
              submittedAssignments: 5,
              totalAssignments: 5
            });
          }
        }

        user.studentRef = student._id;
        await user.save();
        user = await User.findById(user._id).populate('studentRef').populate('assignedSubjects');
      }

      res.json({
        success: true,
        data: {
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          department: user.department,
          status: user.status,
          studentRef: user.studentRef,
          assignedSubjects: user.assignedSubjects,
          token: generateToken(user._id)
        }
      });
    } else {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get current user profile
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
  try {
    let user = await User.findById(req.user._id).populate('studentRef');
    if (user && user.role === 'student' && !user.studentRef) {
      let student = await Student.findOne({ email: user.email });
      if (!student) {
        student = await Student.findOne({ name: new RegExp('^' + user.name.trim() + '$', 'i') });
      }
      if (student) {
        user.studentRef = student._id;
        await user.save();
        user = await User.findById(req.user._id).populate('studentRef');
      }
    }
    res.json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { registerUser, loginUser, getMe };
